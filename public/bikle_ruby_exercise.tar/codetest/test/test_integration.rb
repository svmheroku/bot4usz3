# test_integration.rb

# The rb-files I want to test are in a sibling-dir named 'lib'.
require File.expand_path(File.dirname(__FILE__) + '/../lib/chem.rb')
require File.expand_path(File.dirname(__FILE__) + '/../lib/sched_use.rb')
require 'test/unit'
require 'date'

class TestIntegration < Test::Unit::TestCase

  # Edge case: Out of Chemical and 0 scheduled uses.
  # We should see a prediction of today.
  def test_no_chem_no_sched_uses
    ourwater = Chem.new
    ourwater.name = 'H20'
    predicted_day = ourwater.day_when_out
    dtn = DateTime.now
    today = dtn - dtn.day_fraction
    assert_equal(predicted_day, today)
  end

  # Edge case: Out of Chemical and 1 scheduled use.
  # We should see a prediction of today.
  def test_no_chem_1_sched_use
    ourwater = Chem.new
    ourwater.name = 'H20'
    dans_water_use = SchedUse.new
    dans_water_use.amount = 1.1
    dans_water_use.periodicity = 'daily'
    dans_water_use.start_date = DateTime.now
    dans_water_use.end_date = DateTime.now + 3 # About 3 days from now
    ourwater.sched_uses << dans_water_use
    predicted_day = ourwater.day_when_out
    dtn = DateTime.now
    today = dtn - dtn.day_fraction
    assert_equal(predicted_day, today)
  end

  # We have 101 Kg of water. Sole user Dan consumes 100 Kg daily.
  # We predict water will last through today (until tomorrow).
  def test_1_chem_1_sched_use
    ourwater = Chem.new
    ourwater.name = 'H20'
    ourwater.current_amount = 101.0
    dans_water_use = SchedUse.new
    dans_water_use.amount = 100.0
    dans_water_use.periodicity = 'daily'
    day_now = DateTime.now
    dans_water_use.start_date = day_now
    dans_water_use.end_date = day_now + 3 # About 3 days from now.
    ourwater.sched_uses << dans_water_use
    predicted_day = ourwater.day_when_out
    tomorrow = day_now + 1 - day_now.day_fraction
    assert_equal(predicted_day, tomorrow)
  end


  # Today, We have 101 Kg of water. 
  # Starting today, Dan consumes 50 Kg daily.
  # Starting tomorrow, Krishna consumes 50 Kg daily.
  # After today we have 51 Kg.
  # After tomorrow we have 51 - 50 - 50 which is -49 Kg.
  # So, we predict water will last through today (until tomorrow).
  def test_1_chem_2_sched_use
    ourwater = Chem.new
    ourwater.name = 'H20'
    ourwater.current_amount = 101.0

    dans_water_use = SchedUse.new
    dans_water_use.amount = 50.0
    dans_water_use.periodicity = 'daily'
    day_now = DateTime.now
    dans_water_use.start_date = day_now
    dans_water_use.end_date = day_now + 3 # About 3 days from now.

    krishnas_water_use = SchedUse.new
    krishnas_water_use.amount = 50.0
    krishnas_water_use.periodicity = 'daily'
    krishnas_water_use.start_date = day_now + 1

    ourwater.sched_uses << dans_water_use
    ourwater.sched_uses << krishnas_water_use

    predicted_day = ourwater.day_when_out
    tomorrow = day_now + 1 - day_now.day_fraction
    assert_equal(predicted_day, tomorrow)
  end


  # Today, We have 100 Kg of water. 
  # Starting tomorrow, Dan consumes 100 Kg daily.
  # So, we predict water will last through tomorrow.
  def test_1_chem_1_sched_use_tomorrow
    ourwater = Chem.new
    ourwater.name = 'H20'
    ourwater.current_amount = 100.0
    dans_water_use = SchedUse.new
    dans_water_use.amount = 100.0
    dans_water_use.periodicity = 'daily'
    day_now = DateTime.now
    dans_water_use.start_date = day_now + 1
    ourwater.sched_uses << dans_water_use
    predicted_day = ourwater.day_when_out
    tomorrow = day_now + 1 - day_now.day_fraction
    assert_equal(predicted_day, tomorrow)
  end

  # Today, We have 101 Kg of water. 
  # Starting today, Dan consumes 700 Kg weekly.
  # So, we predict water will last through today.
  def test_1_chem_1_sched_use_weekly
    ourwater = Chem.new
    ourwater.name = 'H20'
    ourwater.current_amount = 101.0
    dans_water_use = SchedUse.new
    dans_water_use.amount = 700.0
    dans_water_use.periodicity = 'weekly'
    day_now = DateTime.now
    dans_water_use.start_date = day_now
    ourwater.sched_uses << dans_water_use
    predicted_day = ourwater.day_when_out
    today = day_now + 1 - day_now.day_fraction
    assert_equal(predicted_day, today)
  end

end

