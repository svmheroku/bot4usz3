# test_chem.rb
# This file was patterned off of Unit Testing Chapter in the "Pick Axe" book.

# The rb-files I want to test are in a sibling-dir named 'lib'.
require File.expand_path(File.dirname(__FILE__) + '/../lib/chem.rb')
require File.expand_path(File.dirname(__FILE__) + '/../lib/sched_use.rb')
require 'test/unit'

class TestChem < Test::Unit::TestCase

  # A Chemical should have a name which is a String.
  def test_name
    somewater = Chem.new
    somewater.name = 'H2O'
    assert_equal somewater.name,'H2O'
  end

  # A Chemical has many scheduled uses which are stored in an Array.
  def test_sched_uses
    somewater = Chem.new
    somewater.sched_uses << SchedUse.new
    assert_equal somewater.sched_uses.count, 1
  end

  # I should be able to get/set current_amount which is a Float.
  def test_current_amount
    somewater = Chem.new
    somewater.current_amount = 100.1
    assert_equal somewater.current_amount, 100.1
  end
end

