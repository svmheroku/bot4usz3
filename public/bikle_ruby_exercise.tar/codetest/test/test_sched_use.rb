# test_sched_use.rb

require File.expand_path(File.dirname(__FILE__) + '/../lib/sched_use.rb')
require 'test/unit'
require 'date'

class TestSchedUse < Test::Unit::TestCase

  # A scheduled use has one amount which is a decimal number (a Float).
  def test_amount
    large_amount_of_liquid = SchedUse.new
    large_amount_of_liquid.amount = 100.1
    assert_equal large_amount_of_liquid.amount, 100.1
  end

  # A scheduled use has a periodicity which is a String.
  def test_periodicity
    daily_use_of_liquid = SchedUse.new
    daily_use_of_liquid.periodicity = 'daily'
    assert_equal daily_use_of_liquid.periodicity, 'daily'
  end

  # A scheduled use has a start_date which is a DateTime object.
  def test_start_date
    some_liquid = SchedUse.new
    today = DateTime.now
    some_liquid.start_date = today
    # start_date should have no fraction:
    assert_equal some_liquid.start_date, (today - today.day_fraction)
  end

  # A scheduled use has an end_date which is a DateTime object.
  def test_end_date
    some_liquid = SchedUse.new
    tomorrow = DateTime.now + 1
    some_liquid.end_date = tomorrow
    # end_date should have no fraction:
    assert_equal some_liquid.end_date, (tomorrow - tomorrow.day_fraction)
  end

end

