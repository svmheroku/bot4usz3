# chem.rb
require 'date'

class Chem
  attr_accessor :name, :current_amount, :sched_uses

  def initialize
    @sched_uses = []
    # The Unit of Measure for current_amount is Kg.
    @current_amount = 0.0 # Kg
  end

  # Predict when scheduled uses of this chemical will deplete our store.
  def day_when_out
    # Deal with some edge-cases and then the happy path.
    dt_now = DateTime.now
    @today = dt_now - dt_now.day_fraction

    # Edge case: We are out now.
    return @today if @current_amount <= 0.0

    # Edge case: We are not using this Chemical now.
    # Arbitrarily predict a depletion date of 20 years from now.
    # I'd like to return some kind of message but this method is supposed to return a point in time.
    total_kg_per_day = 0.0
    @sched_uses.each { |su|
      total_kg_per_day += su.amount 
    }
    return @today + 365 * 20 if(total_kg_per_day <= 0.0 or total_kg_per_day == 0)

    # Happy path:
    # Use a nested loop where I loop through each day and then through each scheduled use.
    amount_left = @current_amount
    # Convert todays date to an integer which is useful for looping.
    mjd = @today.mjd
    while amount_left > 0.0 do
      @sched_uses.each { |su|
        # For this su get start_date and end_date
        enddate = startdate = nil
        enddate = su.end_date.mjd unless su.end_date.nil?
        if su.start_date.nil?
          startdate = @today
        else
          startdate = su.start_date.mjd
        end
        # I have 2 different cases which consume the chemical.
        # su is after start_date and has no end_date
        # OR
        # su is after start_date and before end_date
        if((startdate <= mjd) and (enddate.nil? or mjd <= enddate))
          amount_left -= su.amount if su.periodicity == 'daily'
          amount_left -= su.amount / 7.0 if su.periodicity == 'weekly'
        end
      }
      # Think of the outer loop as going to the next day.
      mjd = mjd + 1
    end # while
    # mjd has been incremented by a number of days.
    # I use the delta to help display the prediction:
    return @today + (mjd - @today.mjd - 1)
  end # def time_when_out

end
