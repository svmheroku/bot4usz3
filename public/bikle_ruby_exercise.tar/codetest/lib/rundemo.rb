#!/usr/bin/env ruby

# This script demonstrates a simple API to interact with two Ruby classes.
# Demo:
# cd dan_projects/cdd
# ruby lib/rundemo.rb

require File.expand_path(File.dirname(__FILE__) + '/chem.rb')
require File.expand_path(File.dirname(__FILE__) + '/sched_use.rb')
require 'date'

class Rundemo
  def runnow

    ourwater = Chem.new
    ourwater.name = 'H20'
    ourwater.current_amount = 101.0
    p "Currently, we have #{ourwater.current_amount} Kg of #{ourwater.name}"

    dans_water_use = SchedUse.new
    dans_water_use.amount = 50.0
    dans_water_use.periodicity = 'daily'
    day_now = DateTime.now
    dans_water_use.start_date = day_now
    dans_water_use.end_date = day_now + 3 # About 3 days from now.

    p "Starting #{dans_water_use.start_date.to_s[0..9]},"
    p "through #{dans_water_use.end_date.to_s[0..9]},"
    p "Dan uses #{dans_water_use.amount} Kg of #{ourwater.name} #{dans_water_use.periodicity}."

    krishnas_water_use = SchedUse.new
    krishnas_water_use.amount = 50.0
    krishnas_water_use.periodicity = 'daily'
    krishnas_water_use.start_date = day_now + 1

    p "Starting #{krishnas_water_use.start_date.to_s[0..9]},"
    p "Krishna uses #{krishnas_water_use.amount} Kg of #{ourwater.name} #{krishnas_water_use.periodicity}."

    ourwater.sched_uses << dans_water_use
    ourwater.sched_uses << krishnas_water_use

    predicted_day = ourwater.day_when_out

    p "We have enough #{ourwater.name} to last through #{predicted_day.to_s[0..9]}"
  end
end

@run = Rundemo.new
@run.runnow


