# sched_use.rb
require 'date'

class SchedUse
  attr_reader :end_date, :start_date, :periodicity, :amount
  def initialize
    @amount = 0.0
    @periodicity = 'daily'
    @start_date = DateTime.now
    # I dont want fractions on my date attributes.
    @start_date -= @start_date.day_fraction
  end
  
  def start_date=(sd)
    @start_date = sd - sd.day_fraction
  end

  def end_date=(ed)
    @end_date = ed - ed.day_fraction
  end

  def periodicity=(dw)
    if dw == 'weekly'
      @periodicity = 'weekly'
    else
      @periodicity = 'daily'
    end
  end

  def amount=(amt)
    @amount = Float amt
  end
end
