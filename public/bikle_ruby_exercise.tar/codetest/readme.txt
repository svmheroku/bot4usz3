readme.txt

This directory contains a small Ruby exercise.

The behavior of this software is specified in an e-mail:

Your users like the chemical inventory system you built for them, but
sometimes they unexpectedly run out of a chemical and have to wait for
resupply. After discussing this with them, you realize that many uses
recur at defined intervals, and this can help you forecast when the
chemical will run out.

For this code problem, you will write the algorithm to predict when a
chemical will run out. Please use Ruby (core library only) and include
plenty of specs/tests in your favorite testing framework.

    Scheduled use
        A scheduled use has an amount, a periodicity, a start date and an optional end date
        A scheduled use's periodicity can be daily or weekly (on a particular day of the week)

    Given a current amount and a set of scheduled uses, predict when the chemical will run out
        If the last use brings the amount to zero, then return the date of the last use
        If any use makes the amount negative, return the date of the latest use that did not incur a negative balance



Simple shell scripts which demonstrate the software are listed below:

bin/rundemo.bash
bin/runtests.bash


A screen dump of some behavior of the software is displayed below:

oracle@z3:/pt/l/customers/cdd/ct$ 
oracle@z3:/pt/l/customers/cdd/ct$ 
oracle@z3:/pt/l/customers/cdd/ct$ bin/runtests.bash
Loaded suite test/test_chem
Started
...
Finished in 0.000495 seconds.

3 tests, 3 assertions, 0 failures, 0 errors, 0 skips

Test run options: --seed 35563
Loaded suite test/test_sched_use
Started
....
Finished in 0.000694 seconds.

4 tests, 4 assertions, 0 failures, 0 errors, 0 skips

Test run options: --seed 47913
Loaded suite test/test_integration
Started
......
Finished in 0.001430 seconds.

6 tests, 6 assertions, 0 failures, 0 errors, 0 skips

Test run options: --seed 12979
oracle@z3:/pt/l/customers/cdd/ct$ 
oracle@z3:/pt/l/customers/cdd/ct$ 
oracle@z3:/pt/l/customers/cdd/ct$ 
oracle@z3:/pt/l/customers/cdd/ct$ bin/rundemo.bash 
"Currently, we have 101.0 Kg of H20"
"Starting 2012-05-31,"
"through 2012-06-03,"
"Dan uses 50.0 Kg of H20 daily."
"Starting 2012-06-01,"
"Krishna uses 50.0 Kg of H20 daily."
"We have enough H20 to last through 2012-06-01"
oracle@z3:/pt/l/customers/cdd/ct$ 
oracle@z3:/pt/l/customers/cdd/ct$ 
oracle@z3:/pt/l/customers/cdd/ct$ 



